create table CST499.tblEnrollments(
	e_id			INT				auto_increment primary key,
	e_course		VARCHAR(15)		not null,
	e_account		VARCHAR(50)		not null,
	e_count			INT				NOT null,
    constraint fk_enroll_account 
    	foreign key (e_account)
    	REFERENCES tblAccounts (a_email)
    	ON DELETE CASCADE,
    constraint fk_enroll_course 
    	foreign key (e_course)
    	REFERENCES tblCourses (c_id)
    	ON DELETE CASCADE
);
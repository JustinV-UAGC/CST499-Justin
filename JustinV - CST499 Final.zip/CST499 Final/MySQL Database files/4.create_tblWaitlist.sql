create table CST499.tblWaitlist(
	w_id			INT				auto_increment primary key,
	account_id		VARCHAR(50)		not null,
	course_id		VARCHAR(15)		not null,
    constraint fk_wait_account 
    	foreign key (account_id)
    	REFERENCES tblAccounts (a_email)
    	ON DELETE CASCADE,
    constraint fk_wait_course 
    	foreign key (course_id)
    	REFERENCES tblCourses (c_id)
    	ON DELETE CASCADE
);
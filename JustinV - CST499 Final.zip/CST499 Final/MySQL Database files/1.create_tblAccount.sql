create table CST499.tblAccounts(
	a_email			VARCHAR(50)		not null primary key,
	a_password		VARCHAR(30)		not null,
	a_firstName		VARCHAR(30)		not null,
	a_lastName		VARCHAR(30)		not null,
	a_DOB			VARCHAR(10)		not null,
	a_phone			VARCHAR(16)		not null
);
create table CST499.tblCourses(
	c_id			VARCHAR(15)		not null primary key,
	c_name			VARCHAR(7)		not null,
	c_semester		VARCHAR(6)		not null check (c_semester in ('Spring', 'Summer', 'Fall')),
	c_maxEnroll		INT(3)			not null
);
insert into CST499.tblWaitlist values
	(default,'slopez@uagc.edu','CST313spr'),
	(default,'slopez@uagc.edu','CST310fall'),
	(default,'kbrown@uagc.edu','GEN499sum'),
	(default,'slopez@uagc.edu','CST499fall'),
	(default,'rsmith@uagc.edu','GEN499sum')
;

insert into CST499.tblCourses values
	('CST301spr','CST301','Spring',2),
	('CST301sum','CST301','Summer',1),
	('CST301fall','CST301','Fall',3),
	('CST310spr','CST310','Spring',5),
	('CST310fall','CST310','Fall',1),
	('CST313fall','CST313','Fall',3),
	('CST313spr','CST313','Spring',1),
	('CST313sum','CST313','Summer',1),
	('CST316sum','CST316','Summer',3),
	('CST316fall','CST316','Fall',3),
	('CST499fall','CST499','Fall',1),
	('CST499spr','CST499','Spring',1),
	('CST499sum','CST499','Summer',1),
	('GEN499spr','GEN499','Spring',2),
	('GEN499fall','GEN499','Fall',2),
	('GEN499sum','GEN499','Summer',1)
;
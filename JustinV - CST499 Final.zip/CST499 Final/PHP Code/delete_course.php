<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	session_start();
?>

<?php require 'DBconnect.php';

require 'courseVariables.php'; ?>

<?php 


	
if ($catalogVerify == 0) {
		echo "<script>
				alert('Course not found. Input a valid Course ID');
				window.location.href='course_catalog.php';
				</script>";
}	else if ($courseVerify == 1) {
		$enrDelete = "DELETE FROM tblEnrollments WHERE e_course='$course' 
			and e_account = '$student'";
		mysqli_query($con, $enrDelete);
		echo "<script>
				alert('You have been removed from $course');
				window.location.href='course_catalog.php';
				</script>";
}	else if ($waitVerify == 1) {
		$waitDelete = "DELETE FROM tblWaitlist WHERE course_id='$course' 
			and account_id = '$student'";
		mysqli_query($con, $waitDelete);
		echo "<script>
				alert('You have been removed from $course');
				window.location.href='course_catalog.php';
				</script>";			
}	echo "<script>
				alert('You are not enrolled or on the waitlist for $course');
				window.location.href='course_catalog.php';
				</script>";


mysqli_close($con);
?>
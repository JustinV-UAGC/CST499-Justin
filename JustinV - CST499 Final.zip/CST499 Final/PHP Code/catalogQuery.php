<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
session_start();

?>

<?php require 'DBconnect.php';


require 'masterVariables.php';

if ($joinVerify > 0) {
	$fetch = mysqli_fetch_all($joinResult, MYSQLI_ASSOC);


?>

<h3>Course List</h3>
<table border ='1'>
	<tr>
		<th>Course ID</th>
		<th>Course Name</th>
		<th>Semester</th>
		<th>Maximum Enrollments</th>
		<th>Currently Enrolled</th>
	</tr>
	<?php foreach($fetch as $row): ?>
	<tr>
    <td><?= htmlspecialchars($row['e_course']) ?></td>
    <td><?= htmlspecialchars($row['c_name']) ?></td>
	<td><?= htmlspecialchars($row['c_semester']) ?></td>
	<td><?= htmlspecialchars($row['c_maxEnroll']) ?></td>
	<td><?= htmlspecialchars($row['enrolled']) ?></td>
	</tr>
	<?php endforeach ?>	
</table>

<?php } else {
    echo "<h4>No available courses</h4>";
}
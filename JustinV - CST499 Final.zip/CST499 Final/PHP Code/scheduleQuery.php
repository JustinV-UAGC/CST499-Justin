<?php
	error_reporting(E_ALL ^ E_NOTICE);

?>

<?php require 'DBconnect.php'; ?>

	
<?php require 'masterVariables.php'; ?>

<br> 

<?php


if ($scheduleVerify > 0) {

$schedFetch = mysqli_fetch_all($scheduleResult, MYSQLI_ASSOC);

?>

<h3>My Schedule</h3>
<table border ='1'>
	<tr>
		<th>Course ID</th>
		<th>Course Name</th>
		<th>Semester</th>

	</tr>
	<?php foreach($schedFetch as $schedRow): ?>
	<tr>
    <td><?= htmlspecialchars($schedRow['e_course']) ?></td>
    <td><?= htmlspecialchars($schedRow['c_name']) ?></td>
	<td><?= htmlspecialchars($schedRow['c_semester']) ?></td>
	</tr>
	<?php endforeach ?>	
</table>

<?php }

else {
	
	echo "<h4>You are not enrolled in any course</h4>";
}?>

<br><br>

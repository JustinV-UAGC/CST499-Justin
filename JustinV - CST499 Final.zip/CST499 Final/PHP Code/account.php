<?php
	error_reporting(E_ALL ^ E_NOTICE);
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title> Profile Page </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
		<script src="ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>


<?php require 'master.php';

require 'DBconnect.php';

require 'masterVariables.php';

$credRow = mysqli_fetch_array($credResult, MYSQLI_ASSOC);

?>


<div class="container text-center">
<h1>Welcome <?php echo $credRow["a_firstName"], " ", $credRow["a_lastName"]; ?></h1>
</div>
	
<?php

require 'scheduleQuery.php';

require 'waitlistQuery.php'; 

?>


<br><br><h4>Disenroll from a course:</h4>
<form action="delete_course.php" method="POST">
	<input type="hidden" id="student" name "student" value="<?php 
	if(isset($_SESSION['email'])) {
		echo htmlentities ($_SESSION['email']); }?>"/>
	Course ID: <input type="text" name="course" required/>
	<button type="submit">Submit</button>
</form>


<?php require 'course_availability.php'; ?>


<li><br><br><a href="course_catalog.php"><span class="glyphicon glyphicon-list-alt">
	</span> Register for Courses</a><br><br></li>

<?php require_once 'footer.php';

mysqli_close($con);?>	


</body>
</html>

<?php
	error_reporting(E_ALL ^ E_NOTICE);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title> Registration Page </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
		<script src="ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Account Registration Page</h1>
	</div>

<form action="add_accounts.php" method="POST">
	Email Address: <input type="email" name="email" required/> <br>
	Password: <input type="text" name="password" required/> <br>
	First Name: <input type="text" name="firstName" required/> <br>
	Last Name: <input type="text" name="lastName" required/> <br>
	Date of Birth:<input type="date" name="DOB" required/> <br>
	Phone Number:<input type="tel" name="phone" placeholder="123-456-7890"
		pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required/><br>
		<small>Format: 123-456-7890</small><br>
	<button type="submit">Submit</button>
</form>

<?php require_once 'footer.php';?>	

</body>
</html>

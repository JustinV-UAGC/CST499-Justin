<?php
	error_reporting(E_ALL ^ E_NOTICE);
	ini_set('session.use_only_cookies','1');
	if(isset($_SESSION['email']))
		echo "Welcome: " . $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
	<script src="ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>
<div class="jumbotron">
	<div class="container text-center">
		<h1>CST499 - Justin Villanueva</h1>
	</div>
</div>
	
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
		<?php	
			ini_set('session.use_only_cookies','1');
			session_start();

			
			if(isset($_SESSION['email']))
			{
				echo '<li><a href="account.php"><span class="glyphicon glyphicon-user"></span> Profile</a></li>';
				echo '<li><a href="logout.php?Logout=1"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>';
			}	
			else
			{
				echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
				echo '<li><a href="registration.php?Logout=1"><span class="glyphicon glyphicon-registration-mark">
					</span>	Registration</a></li>';
			}	
		?>
			</ul>
		</div>
	</div>
</nav>
</body>
</html>
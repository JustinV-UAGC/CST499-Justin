<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
session_start();

?>

<?php require 'DBconnect.php';

require 'masterVariables.php';


$student = $_SESSION['email'];


//get student's waitlisted classes
if ($waitlistVerify > 0) {
	$limit = $waitlistVerify;
	$i = 0;
	$waitFetch = mysqli_fetch_all($waitlistResult, MYSQLI_NUM);
	
	foreach($waitFetch as $listRow) {
		if ($i >= $limit) break;	
			$courseRow = $listRow[2];
			$studentRow = $listRow[1];
			
			//get first priority for waitlist
			$waitPosn = "SELECT * FROM tblWaitlist WHERE course_id = '$courseRow' limit 1";
			$posnResult = mysqli_query($con, $waitPosn);
			$posnFetch = mysqli_fetch_all($posnResult, MYSQLI_ASSOC);

			foreach($posnFetch as $posnRow){
				$posnID = $posnRow['w_id'];
				$posnCourse = $posnRow['course_id'];
				$posnAcct = $posnRow['account_id'];
			
				
			//capacity query
			$capacity = "select tblenrollments.e_course, tblcourses.c_maxEnroll,
				sum(e_count) as enrolled FROM tblenrollments
				inner JOIN tblcourses on e_course = c_id
				where e_course = '$posnCourse'";
			$capacityResult = mysqli_query($con, $capacity);
			$capacityFetch = mysqli_fetch_assoc($capacityResult);


			if (($posnAcct == $studentRow) AND ($capacityFetch['c_maxEnroll'] > $capacityFetch['enrolled'])) { ?> 
			
				<form action="waitlist_change.php" method="POST">
				<p><br><br><b><?php echo $posnCourse; ?></b> is now available.
					<br>Would you like to enroll in <b><?php echo $posnCourse; ?></b>?</p>
				<input type="hidden" id="posnCourse" name="posnCourse" 
					value="<?php echo htmlentities($posnCourse);?>">
				<input type="hidden" id="student" name="student" 
					value="<?php echo htmlentities($student); ?>">
				<input type="radio" id="YES" name="choice" value="YES">
				<label for="YES">YES</label>
				<input type="radio" id="NO" name="choice" value="NO">
				<label for="NO">NO</label>
				<input type="submit" value="Submit">
				</form>
				
<?php		} 
			$i++;
		} 
	} 
} 


?>





<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
session_start();
?>

<?php require 'DBconnect.php';?>

<?php 

$email = $_REQUEST['email'];
$password = $_REQUEST['password'];
$firstName = $_REQUEST['firstName'];
$lastName = $_REQUEST['lastName'];
$DOB = $_REQUEST['DOB'];
$phone = $_REQUEST['phone'];


$insert = "INSERT INTO tblAccounts VALUES ('$email', '$password', 
	'$firstName', '$lastName', '$DOB', '$phone')";


$acctSel = "SELECT * FROM tblAccounts WHERE a_email='$email'";
$result = mysqli_query($con, $acctSel);
$verify = mysqli_num_rows($result);
$form = (empty($email) or empty($password) or empty($firstName) or 
	empty($lastName) or empty($DOB) or empty($phone));

	
if ($verify == 1) {
		echo "<script>
				alert('Email is already registered. Input a New Email');
				window.location.href='registration.php';
				</script>";
}	else if ($verify == 0) {
		mysqli_query($con, $insert);
		$_SESSION['email'] = $email;
		$_SESSION['password'] = $password;
		echo "<script>
				alert('Account registration successful');
				window.location.href='account.php';
				</script>";
}

mysqli_close($con);
?>
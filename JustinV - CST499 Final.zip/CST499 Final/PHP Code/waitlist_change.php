<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	session_start();
	
?>

<?php require 'DBconnect.php'; ?>

<?php 
 
$choice = $_POST['choice'];
$posnCourse = $_POST['posnCourse'];
$student = $_SESSION['email'];

if ($choice == 'YES') {
	
	//enroll in class
	$enrollInsert = "INSERT INTO tblEnrollments VALUES (default,'$posnCourse','$student',1)";
	mysqli_query($con, $enrollInsert);
		
	
	//remove from waitlist	
	$delete = "DELETE FROM tblWaitlist WHERE course_id='$posnCourse' and account_id = '$student'";
	mysqli_query($con, $delete);
			
		echo "<script>
			alert('You have successfully registered into $posnCourse');
			window.location.href='account.php';
			</script>";
			
} else  {
	//remove from waitlist	
	$delete = "DELETE FROM tblWaitlist WHERE course_id='$posnCourse' and account_id = '$student'";
	mysqli_query($con, $delete);
		echo "<script>
			alert('You have been removed from $posnCourse');
			window.location.href='account.php';
			</script>";	
}


mysqli_close($con);
?>
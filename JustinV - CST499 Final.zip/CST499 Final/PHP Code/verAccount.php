<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
session_start();

?>

<?php require 'DBconnect.php';?>


<?php

$email = $_POST['email'];
$password = $_POST['password'];


$acctSel = "SELECT * FROM tblAccounts WHERE a_email='$email' AND a_password='$password'";
$result = mysqli_query($con, $acctSel);
$verify = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);


if($verify == 1){
	$_SESSION['email'] = $row['a_email'];
	$_SESSION['password'] = $password;
	header('Location: account.php');
}	else{
	echo "<script>
		alert('Invalid email or password');
		window.location.href='login.php';
		</script>";
}


mysqli_close($con);

?>
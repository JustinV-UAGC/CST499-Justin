<?php
	error_reporting(E_ALL ^ E_NOTICE);
?>

<?php require 'DBconnect.php';?>

<?php 

$course = $_POST['course'];
$student = $_SESSION['email'];

//check if course is valid
$catalogSel = "SELECT * FROM tblCourses WHERE c_id='$course'";
$catalogResult = mysqli_query($con, $catalogSel);
$catalogVerify = mysqli_num_rows($catalogResult);


//check courses student is enrolled into
$courseSel = "SELECT * FROM tblEnrollments WHERE e_course='$course' 
	and e_account = '$student'";
$courseResult = mysqli_query($con, $courseSel);
$courseVerify = mysqli_num_rows($courseResult);


//check courses student is waitlisted into
$waitSel = "SELECT * FROM tblWaitlist WHERE course_id='$course' 
	and account_id = '$student'";
$waitResult = mysqli_query($con, $waitSel);
$waitVerify = mysqli_num_rows($waitResult);


//check courses student is waitlisted into
$respSel = "SELECT * FROM tblWaitlist WHERE course_id='$course'";
$respResult = mysqli_query($con, $respSel);
$respVerify = mysqli_num_rows($respResult);


//capacity query
$capacity = "select tblenrollments.e_course, tblcourses.c_maxEnroll,
	sum(e_count) as enrolled FROM tblenrollments
	inner JOIN tblcourses on e_course = c_id
	where e_course = '$course'";
$capacityResult = mysqli_query($con, $capacity);
$capacityFetch = mysqli_fetch_assoc($capacityResult);

?>
<?php
	error_reporting(E_ALL ^ E_NOTICE);
?>

<?php require 'DBconnect.php';?>

<?php 


$sess_email = $_SESSION['email'];
$sess_password = $_SESSION['password'];

//Courses query
$courseJoin = "SELECT tblenrollments.e_course, tblcourses.c_name, 
		tblcourses.c_semester, tblcourses.c_maxEnroll,
	sum(e_count) as enrolled FROM tblenrollments 
	inner JOIN tblcourses on e_course = c_id
	GROUP BY e_course";
$joinResult = mysqli_query($con, $courseJoin);
$joinVerify = mysqli_num_rows($joinResult);


//Waitlist query
$waitlistJoin = "SELECT tblWaitlist.w_id, tblWaitlist.account_id, tblWaitlist.course_id, 
		tblcourses.c_name, tblcourses.c_semester
	FROM tblWaitlist 
	inner JOIN tblcourses on course_id = c_id WHERE account_id = '$sess_email'
	GROUP BY course_id";
$waitlistResult = mysqli_query($con, $waitlistJoin);
$waitlistVerify = mysqli_num_rows($waitlistResult);


//Schedule query
$scheduleJoin = "SELECT tblenrollments.e_account, tblenrollments.e_course, 
		tblcourses.c_name, tblcourses.c_semester
	FROM tblenrollments 
	inner JOIN tblcourses on e_course = c_id WHERE e_account = '$sess_email'
	GROUP BY e_course";
$scheduleResult = mysqli_query($con, $scheduleJoin);
$scheduleVerify = mysqli_num_rows($scheduleResult);


//Accounts query
$account = "SELECT * from tblaccounts WHERE a_email = '$sess_email'";
$registered = mysqli_query($con, $account);
$loggedin = mysqli_num_rows($registered);


//Credentials query
$credSel = "SELECT * FROM tblAccounts WHERE a_email='$sess_email' AND 
	a_password='$sess_password'";
$credResult = mysqli_query($con, $credSel);
$credVerify = mysqli_num_rows($credResult);

?>
<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
$servername = "localhost";
$username = "root";
$password = NULL;
$dbname = "CST499";

$con = mysqli_connect($servername, $username, $password, $dbname);

if (mysqli_connect_errno()) {
	die(mysqli_connect_error());
}


?>
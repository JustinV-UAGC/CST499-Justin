<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	session_start();
?>

<?php require 'DBconnect.php';

require 'courseVariables.php'; ?>

<?php 

	
if ($catalogVerify == 0) {
		echo "<script>
				alert('Course not found. Input a valid Course ID');
				window.location.href='course_catalog.php';
				</script>";
}	else if ($courseVerify == 1) {
		echo "<script>
				alert('You are already registered to $course. Input a new Course ID');
				window.location.href='course_catalog.php';
				</script>";
}	else if ($waitVerify == 1) {
		echo "<script>
				alert('You are already on the waitlist for $course. Input a new Course ID');
				window.location.href='course_catalog.php';
				</script>";
}	else if ($respVerify > 0) {
			$enrollInsert = "INSERT INTO tblWaitlist VALUES (default,'$student','$course')";
			mysqli_query($con, $enrollInsert);
			echo "<script>
				alert('A student is currently on the waitlist for this class \\nYou have been added to the end of the waitlist');
				window.location.href='course_catalog.php';
				</script>";
}	else if ($capacityFetch['c_maxEnroll'] == $capacityFetch['enrolled']) {
			$enrollInsert = "INSERT INTO tblWaitlist VALUES (default,'$student','$course')";
			mysqli_query($con, $enrollInsert);
		echo "<script>
				alert('The class has reached capacity \\nYou have been added to the course Waitlist');
				window.location.href='course_catalog.php';
				</script>";
}	else if ($_SERVER['REQUEST_METHOD'] == "POST") {
			$enrollInsert = "INSERT INTO tblEnrollments VALUES (default,'$course','$student',1)";
			mysqli_query($con, $enrollInsert);
		echo "<script>
				alert('You have successfully registered into $course');
				window.location.href='course_catalog.php';
				</script>";
}


mysqli_close($con);
?>
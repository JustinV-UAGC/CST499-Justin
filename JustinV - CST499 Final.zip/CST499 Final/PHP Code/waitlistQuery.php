<?php
	error_reporting(E_ALL ^ E_NOTICE);

?>

<?php require 'DBconnect.php';

require 'masterVariables.php';

if ($waitlistVerify > 0) {
	$waitFetch = mysqli_fetch_all($waitlistResult, MYSQLI_ASSOC);

?>

	<h3>My Waitlist</h3>
	<table border ='1'>
		<tr>
			<th>Course ID</th>
			<th>Course Name</th>
			<th>Semester</th>

		</tr>
		<?php foreach($waitFetch as $waitRow): ?>
		<tr>
		<td><?= htmlspecialchars($waitRow['course_id']) ?></td>
		<td><?= htmlspecialchars($waitRow['c_name']) ?></td>
		<td><?= htmlspecialchars($waitRow['c_semester']) ?></td>
		</tr>
		<?php endforeach ?>	
	</table>

<?php } 	
	else {
		echo "<h4>You are not enrolled in any course waitlists</h4>";
	}
?>
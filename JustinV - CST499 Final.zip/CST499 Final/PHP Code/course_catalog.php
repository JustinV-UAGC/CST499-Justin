<?php
	error_reporting(E_ALL ^ E_NOTICE);

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title> Course List </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
		<script src="ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Course Catalog</h1>
	</div>


<?php 

require 'DBconnect.php';

require 'scheduleQuery.php';

require 'waitlistQuery.php';?>


<br><br><h4>Disenroll from a course:</h4>
<form action="delete_course.php" method="POST">
	<input type="hidden" id="student" name "student" value="<?php 
	if(isset($_SESSION['email'])) {
		echo htmlentities ($_SESSION['email']); }?>"/>
	Course ID: <input type="text" name="course" required/>
	<button type="submit">Submit</button>
</form><br><br>

<?php require 'catalogQuery.php'; ?>

<br><br><h4>Register into a course:</h4>
<form action="add_course.php" method="POST">
	<input type="hidden" id="student" name "student" value="<?php 
	if(isset($_SESSION['email'])) {
		echo htmlentities ($_SESSION['email']); }?>"/>
	Course ID: <input type="text" name="course" required/>
	<button type="submit">Submit</button>
</form>

<?php require_once 'footer.php';

mysqli_close($con);?>	
</body>
</html>
